# Notebook, history, step-by-step cards with "Ask about this step", Copy and Print/PDF.
# Run:  Set-ExecutionPolicy -Scope Process Bypass; & ".\apply-notebook.ps1" -Project "D:\mathsolver\mathsolveiq"
# This script does NOT deploy. Deploy and push once when you are ready.
param([string]$Project = "D:\mathsolver\mathsolveiq")
$pack = $PSScriptRoot
$utf8 = New-Object System.Text.UTF8Encoding $false
$ip = "$Project\index.html"
if (-not (Test-Path $ip)) { Write-Host "index.html not found in $Project" -ForegroundColor Red; exit 1 }
Set-Location $Project
if (-not (Test-Path ".git")) { git init | Out-Null }
git add -A 2>$null
git commit -m "before notebook" 2>$null | Out-Null

Write-Host "`n--- 1. Files ---" -ForegroundColor Cyan
New-Item -ItemType Directory -Force "$Project\js" | Out-Null
Copy-Item "$pack\js\msiq-notebook.js" "$Project\js\msiq-notebook.js" -Force; Write-Host "OK    js\msiq-notebook.js" -ForegroundColor Green
Copy-Item "$pack\js\solve.js" "$Project\js\solve.js" -Force; Write-Host "OK    js\solve.js (steps, Ask about this step, Save, Copy, Print)" -ForegroundColor Green
Copy-Item "$pack\notebook.html" "$Project\notebook.html" -Force; Write-Host "OK    notebook.html" -ForegroundColor Green
foreach ($f in "js\msiq-notebook.js", "js\solve.js") { node --check "$Project\$f" 2>&1 | Out-Null; if ($LASTEXITCODE -ne 0) { Write-Host "ERROR $f has a syntax error" -ForegroundColor Red } }

Write-Host "`n--- 2. index.html ---" -ForegroundColor Cyan
$t = [IO.File]::ReadAllText($ip)
if (-not $t.Contains("js/msiq-notebook.js")) {
  if ($t.Contains('<script src="js/solve.js"></script>')) {
    $t = $t.Replace('<script src="js/solve.js"></script>', '<script src="js/msiq-notebook.js"></script>' + "`n" + '<script src="js/solve.js"></script>')
    Write-Host "OK    notebook script added before solve.js" -ForegroundColor Green
  } else { Write-Host "NOTE  index.html does not load js/solve.js yet. Run the backend pack first, then run this again." -ForegroundColor Yellow }
} else { Write-Host "ok    notebook script already loaded" -ForegroundColor DarkGreen }
$m = [regex]::Match($t, '(?s)<nav\b[^>]*\bid="nav"[^>]*>.*?</nav>')
if ($m.Success -and -not $m.Value.Contains("notebook.html")) {
  $t = $t.Replace($m.Value, $m.Value.Replace("</nav>", '<a href="notebook.html">My Notebook</a>' + "`n</nav>"))
  Write-Host "OK    My Notebook added to the sidebar menu" -ForegroundColor Green
} elseif (-not $m.Success) { Write-Host "NOTE  Menu not found. Add by hand: <a href=""notebook.html"">My Notebook</a>" -ForegroundColor Yellow }
[IO.File]::WriteAllText($ip, $t, $utf8)

if (Test-Path "$Project\sitemap.xml") {
  $sm = [IO.File]::ReadAllText("$Project\sitemap.xml")
  if (-not $sm.Contains("/notebook.html")) { $sm = $sm.Replace("</urlset>", "  <url><loc>https://mathsolveiq.vercel.app/notebook.html</loc><priority>0.4</priority></url>`n</urlset>"); [IO.File]::WriteAllText("$Project\sitemap.xml", $sm, $utf8); Write-Host "OK    sitemap.xml" -ForegroundColor Green }
}
git add -A 2>$null
git commit -m "notebook, history, step questions, print" 2>$null | Out-Null
Write-Host "`nSaved locally. Not deployed yet. When ready:  npx vercel --prod   then   git push" -ForegroundColor Cyan
