/* MathSolveIQ: connects the home page Solve button to /api/solve, shows steps, saves to the notebook.
   Load AFTER js/app.js and js/msiq-notebook.js. */
(function () {
  var $ = function (i) { return document.getElementById(i); };
  var btn = $("solveBtn"), box = $("q"), out = $("solveOut"), NB = window.MSIQ_NB;
  if (!btn || !box || !out) return;
  var history = [], image = null, busy = false, cur = null;

  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]; }); }
  function mode() {
    var c = document.querySelector("#modes .chip.on"), t = c ? c.textContent.toLowerCase() : "";
    return t.indexOf("hint") > -1 ? "hint" : t.indexOf("socratic") > -1 ? "socratic" : "full";
  }
  function cleanQ() {
    var q = box.value, c = document.querySelector("#modes .chip.on"), pre = c ? (c.dataset.m || "") : "";
    if (pre && q.indexOf(pre) === 0) q = q.slice(pre.length);
    return q.trim();
  }

  /* language: English or Turkish, two buttons (no dropdown) */
  var saved = "English"; try { saved = localStorage.getItem("msiq_lang") === "Turkish" ? "Turkish" : "English"; } catch (e) {}
  window.MSIQ_LANG = saved;
  var langBox = document.createElement("div"); langBox.className = "chips"; langBox.setAttribute("role", "group"); langBox.setAttribute("aria-label", "Answer language");
  [["English", "English"], ["Turkish", "T\u00fcrk\u00e7e"]].forEach(function (l) {
    var b = document.createElement("button"); b.type = "button"; b.className = "chip" + (l[0] === saved ? " on" : ""); b.textContent = l[1]; b.setAttribute("data-lang", l[0]);
    b.onclick = function () {
      window.MSIQ_LANG = l[0]; try { localStorage.setItem("msiq_lang", l[0]); } catch (e) {}
      Array.prototype.forEach.call(langBox.children, function (x) { x.classList.toggle("on", x === b); });
    };
    langBox.appendChild(b);
  });
  var chips = $("modes"); if (chips && chips.parentNode) chips.parentNode.insertBefore(langBox, chips.nextSibling);
  var langSel = { get value() { return window.MSIQ_LANG; } };

  /* photo button */
  var note = document.createElement("div"); note.className = "hint"; out.parentNode.insertBefore(note, out);
  var photoBtn = null;
  Array.prototype.forEach.call(document.querySelectorAll("#page-home button"), function (b) { if (/photo/i.test(b.textContent)) photoBtn = b; });
  if (photoBtn) {
    var f = document.createElement("input"); f.type = "file"; f.accept = "image/*"; f.hidden = true; document.body.appendChild(f);
    photoBtn.disabled = false; photoBtn.removeAttribute("title"); photoBtn.textContent = "📷 Photo";
    photoBtn.onclick = function () { f.click(); };
    f.onchange = function () {
      var file = f.files && f.files[0]; if (!file) return;
      var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        var s = Math.min(1, 1400 / Math.max(img.width, img.height)), c = document.createElement("canvas");
        c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        image = { media_type: "image/jpeg", data: c.toDataURL("image/jpeg", 0.8).split(",")[1] };
        note.textContent = "Photo added: " + file.name + ". Press Solve. (Images only for now, no PDF.)";
        URL.revokeObjectURL(url);
      };
      img.onerror = function () { note.textContent = "Could not read that image."; };
      img.src = url;
    };
  }

  /* ---------- showing answers ---------- */
  function showTurn(q, a, isFollow) {
    if (isFollow) { var u = document.createElement("div"); u.className = "hint"; u.textContent = "You: " + q; out.appendChild(u); }
    out.appendChild(NB.renderAnswer(a, { onStep: function (n, text) { stepQuestion(n, text); } }));
  }
  function stepQuestion(n, text) {
    ask("Please explain step " + n + " in more detail and say why it works: " + String(text).slice(0, 220), true, "Explain step " + n);
  }
  function addTools() {
    var old = $("toolsBox"); if (old) old.remove();
    var old2 = $("followBox"); if (old2) old2.remove();
    var t = document.createElement("div"); t.id = "toolsBox"; t.className = "tools";
    function mkBtn(label, fn) { var b = document.createElement("button"); b.type = "button"; b.textContent = label; b.onclick = function () { fn(b); }; t.appendChild(b); return b; }
    var star = mkBtn(cur && cur.star ? "⭐ Saved" : "☆ Save to notebook", function (b) {
      var it = NB.update(cur.id, function (x) { x.star = !x.star; }); cur.star = it ? it.star : !cur.star;
      b.textContent = cur.star ? "⭐ Saved" : "☆ Save to notebook"; b.classList.toggle("on", !!cur.star);
    });
    if (cur && cur.star) star.classList.add("on");
    mkBtn("📋 Copy", function (b) { NB.copy(NB.toText(NB.get(cur.id) || cur)).then(function (ok) { b.textContent = ok ? "Copied" : "Copy failed"; setTimeout(function () { b.textContent = "📋 Copy"; }, 1500); }); });
    mkBtn("🖨 Print / Save as PDF", function (b) { if (!NB.printItem(NB.get(cur.id) || cur)) { b.textContent = "Allow pop-ups to print"; setTimeout(function () { b.textContent = "🖨 Print / Save as PDF"; }, 2500); } });
    var a = document.createElement("a"); a.href = "notebook.html"; a.textContent = "📓 My notebook"; t.appendChild(a);
    out.appendChild(t);
    var d = document.createElement("div"); d.id = "followBox"; d.className = "row";
    d.innerHTML = '<input id="followQ" placeholder="Did not get something? Ask a follow-up…"><button class="btn fit" id="followGo" type="button">Ask</button>';
    out.appendChild(d);
    var go = function () { var v = $("followQ").value.trim(); if (v) ask(v, true); };
    $("followGo").onclick = go; $("followQ").onkeydown = function (e) { if (e.key === "Enter") go(); };
  }

  async function ask(question, isFollow, label) {
    if (busy) return;
    busy = true; btn.disabled = true;
    var oldT = $("toolsBox"); if (oldT) oldT.remove(); var oldF = $("followBox"); if (oldF) oldF.remove();
    var wrap = document.createElement("div"); wrap.className = "step"; wrap.textContent = "Thinking…";
    if (!isFollow) { out.innerHTML = ""; }
    out.appendChild(wrap);
    try {
      var r = await fetch("/api/solve", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: question, mode: mode(), lang: langSel.value, history: isFollow ? history : [], image: isFollow ? null : image }) });
      var d = await r.json().catch(function () { return {}; });
      if (!r.ok) throw new Error(d.error || "Something went wrong. Please try again.");
      wrap.remove();
      var shown = question || "Solve the problem in the photo.";
      if (!isFollow) {
        history = [];
        cur = NB.add({ id: NB.newId(), t: Date.now(), q: shown, mode: mode(), lang: langSel.value, star: false, turns: [] });
      }
      history.push({ role: "user", content: shown }, { role: "assistant", content: d.answer });
      var turn = { q: label || shown, a: String(d.answer).slice(0, 6000) };
      NB.update(cur.id, function (x) { x.turns.push(turn); }); cur.turns = (cur.turns || []).concat([turn]);
      showTurn(label || shown, d.answer, isFollow);
      addTools();
      try { var ar = JSON.parse(localStorage.getItem("msiq_recent") || "[]"); if (!isFollow && question) { ar = [question].concat(ar.filter(function (x) { return x !== question; })).slice(0, 6); localStorage.setItem("msiq_recent", JSON.stringify(ar)); } } catch (e) {}
    } catch (e) {
      wrap.innerHTML = '<span class="err">' + esc(e.message) + "</span>";
      if (isFollow && cur) addTools();
    }
    busy = false; btn.disabled = false;
  }

  function openItem(it) {
    cur = it; history = []; out.innerHTML = ""; box.value = it.q;
    (it.turns || []).forEach(function (t, i) { history.push({ role: "user", content: t.q }, { role: "assistant", content: t.a }); showTurn(t.q, t.a, i > 0); });
    addTools();
  }

  btn.onclick = function () {
    var q = cleanQ();
    if (!q && !image) { out.innerHTML = '<span class="err">Type a problem or add a photo first.</span>'; return; }
    ask(q, false);
  };

  /* links from the notebook page:  index.html?open=ID   or   index.html?q=text */
  try {
    var qs = new URLSearchParams(location.search), oid = qs.get("open"), qq = qs.get("q");
    if (oid) { var it = NB.get(oid); if (it) openItem(it); }
    else if (qq) { box.value = qq.slice(0, 2000); }
  } catch (e) {}
})();
