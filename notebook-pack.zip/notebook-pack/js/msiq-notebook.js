/* MathSolveIQ notebook library: saves solutions in the browser, splits answers into steps, prints and copies them. */
(function () {
  var KEY = "msiq_notebook";
  function esc(s) { return String(s).replace(/[&<>]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]; }); }
  function fmt(s) { return esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/`([^`]+)`/g, "<code>$1</code>"); }
  function html(s) { return fmt(s).replace(/\n/g, "<br>"); }

  /* ---------- storage ---------- */
  function load() { try { var a = JSON.parse(localStorage.getItem(KEY) || "[]"); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
  function save(a) { try { localStorage.setItem(KEY, JSON.stringify(a.slice(0, 100))); return true; } catch (e) { return false; } }
  function newId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function add(item) { var a = load(); a.unshift(item); save(a); return item; }
  function get(id) { var a = load(); for (var i = 0; i < a.length; i++) if (a[i].id === id) return a[i]; return null; }
  function update(id, fn) { var a = load(); for (var i = 0; i < a.length; i++) if (a[i].id === id) { fn(a[i]); save(a); return a[i]; } return null; }
  function remove(id) { save(load().filter(function (x) { return x.id !== id; })); }
  function clear() { try { localStorage.removeItem(KEY); } catch (e) {} }

  /* ---------- answer -> steps ---------- */
  function parse(text) {
    var lines = String(text || "").split("\n"), intro = [], steps = [], fin = [], cur = null, inFin = false;
    lines.forEach(function (l) {
      var f = l.match(/^\s*(?:\*\*)?(?:Answer|Final answer|Cevap|Yan[ıi]t|Sonu[çc])\s*:\s*(?:\*\*)?\s*(.*)$/i);
      if (f && !inFin) { inFin = true; cur = null; fin.push(f[1]); return; }
      if (inFin) { fin.push(l); return; }
      var m = l.match(/^\s*(?:\*\*)?(?:Step\s*|Ad[ıi]m\s*)?(\d+)\s*[.):](?:\*\*)?\s*(.*)$/i);
      if (m) { cur = { n: m[1], lines: [m[2]] }; steps.push(cur); return; }
      if (!l.trim()) return;
      if (cur) cur.lines.push(l.trim()); else intro.push(l.trim());
    });
    return { intro: intro, steps: steps, final: fin.join("\n").trim() };
  }

  var CSS = ".ans .ansp{margin:8px 0}.stepcard{padding:10px 12px;border:1px solid var(--line);border-radius:12px;margin:8px 0;background:var(--card)}" +
    ".stepcard .sq{display:inline-block;margin-top:6px;border:1px solid var(--line);background:var(--acc2);color:var(--acc);border-radius:8px;padding:4px 10px;font:600 13px system-ui;cursor:pointer}" +
    ".finalbox{border:2px solid var(--acc);background:var(--acc2);border-radius:12px;padding:10px 12px;margin:10px 0}.finalbox small{display:block;color:var(--acc);font-weight:700;margin-bottom:2px}" +
    ".tools{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.tools button,.tools a{border:1px solid var(--line);background:var(--bg);color:var(--ink);border-radius:10px;padding:7px 12px;font:600 14px system-ui;cursor:pointer;text-decoration:none}.tools .on{background:var(--acc);color:var(--bg);border-color:var(--acc)}";
  var styled = false;
  function style() { if (styled || !document.head) return; styled = true; var s = document.createElement("style"); s.textContent = CSS; document.head.appendChild(s); }

  function renderAnswer(text, opts) {
    style(); opts = opts || {};
    var p = parse(text), root = document.createElement("div"); root.className = "ans";
    function para(t) { var d = document.createElement("div"); d.className = "ansp"; d.innerHTML = html(t); root.appendChild(d); }
    if (!p.steps.length && !p.final) { para(String(text || "").trim()); return root; }
    p.intro.forEach(para);
    p.steps.forEach(function (st) {
      var c = document.createElement("div"); c.className = "stepcard";
      var h = document.createElement("b"); h.textContent = "Step " + st.n; c.appendChild(h);
      var b = document.createElement("div"); b.innerHTML = html(st.lines.join("\n")); c.appendChild(b);
      if (opts.onStep) { var q = document.createElement("button"); q.type = "button"; q.className = "sq"; q.textContent = "Ask about this step"; q.onclick = function () { opts.onStep(st.n, st.lines.join(" ")); }; c.appendChild(q); }
      root.appendChild(c);
    });
    if (p.final) { var f = document.createElement("div"); f.className = "finalbox"; var s = document.createElement("small"); s.textContent = "Final answer"; f.appendChild(s); var v = document.createElement("div"); v.innerHTML = html(p.final); f.appendChild(v); root.appendChild(f); }
    return root;
  }

  /* ---------- copy, print, download ---------- */
  function toText(item) {
    var out = ["MathSolveIQ", "", "Question: " + item.q, ""];
    (item.turns || []).forEach(function (t, i) { if (i) out.push("", "Follow-up: " + t.q, ""); out.push(t.a); });
    out.push("", "(AI can make mistakes. Check important work.)");
    return out.join("\n");
  }
  function copy(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return false; });
    return Promise.resolve(false);
  }
  function printItem(item) {
    var body = (item.turns || []).map(function (t, i) { return "<h3>" + (i ? "Follow-up" : "Question") + "</h3><p>" + esc(t.q) + "</p>" + renderAnswer(t.a).outerHTML; }).join("");
    var w = window.open("", "_blank"); if (!w) return false;
    w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>MathSolveIQ solution</title><style>' +
      'body{font:16px/1.6 system-ui,Segoe UI,Arial,sans-serif;max-width:720px;margin:24px auto;padding:0 16px;color:#111}h1{font:700 26px Georgia,serif;color:#0f766e}h3{margin:18px 0 2px}' +
      '.stepcard{border:1px solid #ccc;border-radius:10px;padding:8px 12px;margin:8px 0}.finalbox{border:2px solid #0f766e;background:#e6f4f2;border-radius:10px;padding:8px 12px;margin:10px 0}.finalbox small{display:block;color:#0f766e;font-weight:700}' +
      '.sq{display:none}.foot{color:#666;font-size:13px;margin-top:24px}</style></head><body><h1>MathSolveIQ</h1>' + body + '<p class="foot">AI can make mistakes. Check important work. mathsolveiq.vercel.app</p></body></html>');
    w.document.close(); w.focus(); setTimeout(function () { try { w.print(); } catch (e) {} }, 300);
    return true;
  }
  function download(name, text) {
    var a = document.createElement("a"), u = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
    a.href = u; a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(u); if (a.remove) a.remove(); }, 500);
  }

  var api = { load: load, add: add, get: get, update: update, remove: remove, clear: clear, newId: newId, parse: parse, renderAnswer: renderAnswer, toText: toText, copy: copy, printItem: printItem, download: download, esc: esc };
  if (typeof module !== "undefined" && module.exports) module.exports = api; else window.MSIQ_NB = api;
})();
